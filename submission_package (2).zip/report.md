## Credit Risk Model Report

### Metrics

- accuracy: 1.0
- precision: 1.0
- recall: 1.0
- f1: 1.0
- roc_auc: 1.0
- tuning_time_s: 8.073273181915283

### Best hyperparameters (RandomizedSearchCV)

{
  "clf__subsample": 1.0,
  "clf__n_estimators": 100,
  "clf__max_depth": 3,
  "clf__learning_rate": 0.03,
  "clf__colsample_bytree": 1.0
}

### SHAP Analysis

### Global SHAP summary - top features and impact direction

Top features (by mean |SHAP|):
- _original_target_N: mean |SHAP|=2.1082, mean SHAP=0.2869 → increases default risk
- _original_target_Y: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_VENTURE: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_PERSONAL: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_MEDICAL: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_HOMEIMPROVEMENT: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_EDUCATION: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Intent_DEBTCONSOLIDATION: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Home_RENT: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk
- Home_OWN: mean |SHAP|=0.0000, mean SHAP=0.0000 → decreases default risk

### Local SHAP narratives (two examples)

Case 1 (test index 10) — predicted probability (approx): 0.0088
Top features increasing default risk: None obvious
Top features decreasing default risk: _original_target_N
Suggested action: For high-risk cases consider manual review; for low-risk cases consider automated approval with monitoring.

Case 2 (test index 6503) — predicted probability (approx): 0.9598
Top features increasing default risk: _original_target_N
Top features decreasing default risk: None obvious
Suggested action: For high-risk cases consider manual review; for low-risk cases consider automated approval with monitoring.
